package com.zybooks.weightchangeapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//This class creates databases for the users and the weight recordings

public class Database extends SQLiteOpenHelper {

    // Database Name and Version
    private static final String DATABASE_NAME = "users.db";
    private static final int DATABASE_VERSION = 4;

    // Username table details
    private static final String TABLE_USERS = "users";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";

    // Weight records table details
    private static final String TABLE_WEIGHT_RECORDS = "WeightRecords";
    private static final String COLUMN_DATE = "date";
    private static final String COLUMN_WEIGHT = "weight";
    private static final String COLUMN_LBS_UNTIL_GOAL = "lbs_until_goal";

    // Goals table details
    private static final String TABLE_GOALS = "goals";
    private static final String COLUMN_CURRENT_WEIGHT = "current_weight";
    private static final String COLUMN_TARGET_WEIGHT = "target_weight";
    private static final String COLUMN_TARGET_DATE = "target_date";

    // Constructor
    public Database(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create user table
        String CREATE_USER_TABLE = "CREATE TABLE " + TABLE_USERS + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                COLUMN_USERNAME + " TEXT," +
                COLUMN_PASSWORD + " TEXT)";
        db.execSQL(CREATE_USER_TABLE);

        // Create weight records table
        String CREATE_WEIGHT_RECORDS_TABLE = "CREATE TABLE " + TABLE_WEIGHT_RECORDS + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                COLUMN_DATE + " TEXT," +
                COLUMN_WEIGHT + " TEXT," +
                COLUMN_LBS_UNTIL_GOAL + " TEXT)";
        db.execSQL(CREATE_WEIGHT_RECORDS_TABLE);

        // Create goals table
        String CREATE_GOALS_TABLE = "CREATE TABLE " + TABLE_GOALS + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                COLUMN_CURRENT_WEIGHT + " TEXT," +
                COLUMN_TARGET_WEIGHT + " TEXT," +
                COLUMN_TARGET_DATE + " TEXT)";
        db.execSQL(CREATE_GOALS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 3) {
            // Add weight records table if upgrading from version 1
            String CREATE_WEIGHT_RECORDS_TABLE = "CREATE TABLE " + TABLE_WEIGHT_RECORDS + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                    COLUMN_DATE + " TEXT," +
                    COLUMN_WEIGHT + " TEXT)";
            db.execSQL(CREATE_WEIGHT_RECORDS_TABLE);
        }
        if (oldVersion < 4) {
            // Add goals table if upgrading from version 2
            String CREATE_GOALS_TABLE = "CREATE TABLE " + TABLE_GOALS + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                    COLUMN_CURRENT_WEIGHT + " TEXT," +
                    COLUMN_TARGET_WEIGHT + " TEXT," +
                    COLUMN_TARGET_DATE + " TEXT)";
            db.execSQL(CREATE_GOALS_TABLE);

            // Add lbs_until_goal column to the weight records table
            String ADD_LBS_UNTIL_GOAL_COLUMN = "ALTER TABLE " + TABLE_WEIGHT_RECORDS + " ADD COLUMN " + COLUMN_LBS_UNTIL_GOAL + " TEXT";
            db.execSQL(ADD_LBS_UNTIL_GOAL_COLUMN);
        }
    }

    // Register new user method
    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);
        long result = db.insert(TABLE_USERS, null, values);
        db.close();
        return result != -1;
    }

    // Existing user check method
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS + " WHERE " + COLUMN_USERNAME + "=? AND " + COLUMN_PASSWORD + "=?", new String[]{username, password});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return exists;
    }

    // Goal Creation Method
    public void insertGoal(String currentWeight, String targetWeight, String targetDate) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_CURRENT_WEIGHT, currentWeight);
        contentValues.put(COLUMN_TARGET_WEIGHT, targetWeight);
        contentValues.put(COLUMN_TARGET_DATE, targetDate);
        db.insert(TABLE_GOALS, null, contentValues);
        db.close();
    }

    // Set Target Weight Method
    public String getGoalWeight() {
        SQLiteDatabase db = this.getReadableDatabase();
        String targetWeight = null;

        Cursor cursor = db.query(TABLE_GOALS, new String[]{COLUMN_TARGET_WEIGHT}, null, null, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            int targetWeightIndex = cursor.getColumnIndex(COLUMN_TARGET_WEIGHT);
            if (targetWeightIndex >= 0) {
                targetWeight = cursor.getString(targetWeightIndex);
            } else {
                Log.e("DatabaseHelper", "Column " + COLUMN_TARGET_WEIGHT + " not found");
            }
            cursor.close();
        } else {
            Log.e("DatabaseHelper", "Goals table is empty or not created properly.");
        }

        db.close();

        // Situation where there is no set target weight
        if (targetWeight == null) {
            targetWeight = "0"; // Default value or handle it as needed
        }

        return targetWeight;
    }

    // Add a weight and and date method and returns lbs left to reach goal.
    public void addWeightRecord(String date, String weight, String lbsUntilGoal) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_DATE, date);
        values.put(COLUMN_WEIGHT, weight);
        values.put(COLUMN_LBS_UNTIL_GOAL, lbsUntilGoal);
        db.insert(TABLE_WEIGHT_RECORDS, null, values);
        db.close();
    }

    // Delete a weight record
    public void deleteWeightRecord(String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        int deleteCount = db.delete(TABLE_WEIGHT_RECORDS, COLUMN_DATE + " = ?", new String[]{date});
        db.close();

        if (deleteCount > 0) {
            Log.d("DatabaseHelper", "Deleted " + deleteCount + " records.");
        } else {
            Log.d("DatabaseHelper", "No records to delete.");
        }
    }

    // Sorts records by date to populate the table from oldest to newest entry
    // Necessary in case the user backdates an entry.
    public List<Map<String, String>> getAllWeightRecords() {
        List<Map<String, String>> records = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        // Modify the query to include ORDER BY clause to sort by date
        Cursor cursor = db.query(
                TABLE_WEIGHT_RECORDS,
                new String[]{COLUMN_DATE, COLUMN_WEIGHT, COLUMN_LBS_UNTIL_GOAL},
                null,
                null,
                null,
                null,
                COLUMN_DATE + " ASC"  // Sort by date in ascending order
        );

        if (cursor != null && cursor.moveToFirst()) {
            do {
                int dateIndex = cursor.getColumnIndex(COLUMN_DATE);
                int weightIndex = cursor.getColumnIndex(COLUMN_WEIGHT);
                int lbsUntilGoalIndex = cursor.getColumnIndex(COLUMN_LBS_UNTIL_GOAL);

                if (dateIndex >= 0 && weightIndex >= 0 && lbsUntilGoalIndex >= 0) {
                    Map<String, String> record = new HashMap<>();
                    record.put(COLUMN_DATE, cursor.getString(dateIndex));
                    record.put(COLUMN_WEIGHT, cursor.getString(weightIndex));
                    record.put(COLUMN_LBS_UNTIL_GOAL, cursor.getString(lbsUntilGoalIndex));

                    records.add(record);
                } else {
                    Log.e("DatabaseHelper", "Column index not found");
                }
            } while (cursor.moveToNext());

            cursor.close();
        }
        db.close();
        return records;
    }
}
