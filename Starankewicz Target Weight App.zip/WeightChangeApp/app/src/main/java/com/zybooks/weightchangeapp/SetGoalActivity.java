package com.zybooks.weightchangeapp;

import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.text.method.DigitsKeyListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

// This Class allows the user to set their target weight
public class SetGoalActivity extends AppCompatActivity {
    private Database dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.goal_weight);

        dbHelper = new Database(this);

        EditText currentWeightInput = findViewById(R.id.currentWeightInput);
        EditText targetWeightInput = findViewById(R.id.targetWeightInput);
        EditText targetDateInput = findViewById(R.id.targetDateInput);
        Button enterGoalsButton = findViewById(R.id.enterGoalsButton);
        Button homeButton = findViewById(R.id.homeButton);

        // Int only inputs allowed
        currentWeightInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        targetWeightInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        currentWeightInput.setKeyListener(DigitsKeyListener.getInstance("0123456789"));
        targetWeightInput.setKeyListener(DigitsKeyListener.getInstance("0123456789"));

        // Tells users how to correctly format entry for date
        targetDateInput.setHint("YYYY-MM-DD");

        enterGoalsButton.setOnClickListener(view -> {
            String currentWeight = currentWeightInput.getText().toString().trim();
            String targetWeight = targetWeightInput.getText().toString().trim();
            String targetDate = targetDateInput.getText().toString().trim();

            if (validateInputs(currentWeight, targetWeight, targetDate)) {
                // Saves goals to the database
                dbHelper.insertGoal(currentWeight, targetWeight, targetDate);
                Toast.makeText(SetGoalActivity.this, "Goal set!", Toast.LENGTH_SHORT).show();
                finish(); // Closes activity
            }
        });

        homeButton.setOnClickListener(view -> {
            finish(); // returns to Dashboard without saving
        });
    }

    //Field input validation
    private boolean validateInputs(String currentWeight, String targetWeight, String targetDate) {
        if (TextUtils.isEmpty(currentWeight) || TextUtils.isEmpty(targetWeight) || TextUtils.isEmpty(targetDate)) {
            Toast.makeText(SetGoalActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }
}
