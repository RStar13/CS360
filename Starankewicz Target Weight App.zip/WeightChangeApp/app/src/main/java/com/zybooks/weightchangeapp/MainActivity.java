package com.zybooks.weightchangeapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.zybooks.weightchangeapp.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    private Database dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Initialize Database
        dbHelper = new Database(this);

        // Setup buttons and input fields
        final EditText usernameInput = binding.userNameInput;
        final EditText passwordInput = binding.passwordInput;
        Button loginButton = binding.loginButton;
        Button createAccountButton = binding.createAccountButton;

        // Login Button listender
        loginButton.setOnClickListener(v -> {
            String username = usernameInput.getText().toString();
            String password = passwordInput.getText().toString();
            if (validateLogin(username, password)) {
                Intent intent = new Intent(MainActivity.this, DashboardActivity.class);
                intent.putExtra("USERNAME", username); // Pass the username to DashboardActivity
                startActivity(intent);
            } else {
                Toast.makeText(MainActivity.this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
            }
        });

        // Account Creation Button listener
        createAccountButton.setOnClickListener(v -> {
            String username = usernameInput.getText().toString();
            String password = passwordInput.getText().toString();
            if (usernameExists(username)) {
                Toast.makeText(MainActivity.this, "Username already exists", Toast.LENGTH_SHORT).show();
            } else if (registerNewUser(username, password)) {
                Toast.makeText(MainActivity.this, "Account Created Successfully", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(MainActivity.this, "Account Creation Failed", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private boolean validateLogin(String username, String password) {
        // Check the database for matching username and password
        return dbHelper.checkUser(username, password);
    }

    private boolean registerNewUser(String username, String password) {
        // Add the new user to the database
        if (!username.isEmpty() && !password.isEmpty()) {
            return dbHelper.addUser(username, password);
        } else {
            return false;
        }
    }

    private boolean usernameExists(String username) {
        // Check if the username already exists in the database
        return dbHelper.checkUser(username, "");
    }
}
