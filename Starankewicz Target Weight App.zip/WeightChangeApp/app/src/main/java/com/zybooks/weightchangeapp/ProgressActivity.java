package com.zybooks.weightchangeapp;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import java.util.Map;

public class ProgressActivity extends AppCompatActivity {
    private EditText dateInput, weightInput;
    private RecyclerView recordRecyclerView;
    private RecordAdapter recordAdapter;
    private Database dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.progress_database);

        dbHelper = new Database(this);
        recordRecyclerView = findViewById(R.id.recordRecyclerView);
        dateInput = findViewById(R.id.dateInput);
        weightInput = findViewById(R.id.weightInput);
        Button addDataButton = findViewById(R.id.addDataButton);
        Button homeButton = findViewById(R.id.navHomeButton);

        addDataButton.setOnClickListener(v -> addWeightRecord());
        homeButton.setOnClickListener(v -> finish());

        loadWeightRecords();
    }
    // Add a weight entry to database
    private void addWeightRecord() {
        String date = dateInput.getText().toString().trim();
        String weight = weightInput.getText().toString().trim();

        if (validateInputs(date, weight)) {
            try {
                // Gets goal weight from database
                String goalWeight = dbHelper.getGoalWeight();

                // verifies that goal weight is int
                int targetWeight = Integer.parseInt(goalWeight);
                int currentWeight = Integer.parseInt(weight);

                // Calculate lbsToGoal
                String lbsToGoal = String.valueOf(currentWeight - targetWeight);

                // adds entry to database
                dbHelper.addWeightRecord(date, weight, lbsToGoal);

                // Refresh the list and clear input fields
                loadWeightRecords();
                clearInputs();

                //exceptions handling
            } catch (NumberFormatException e) {
                //notification that weight entry is incorrectly formatted
                Toast.makeText(this, "Invalid weight format", Toast.LENGTH_SHORT).show();
                Log.e("ProgressActivity", "Weights failed to load", e);
            }
        } else {
            // Notifies user that the entry is invalid due to lacking input
            Toast.makeText(this, "Please enter valid date and weight", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean validateInputs(String date, String weight) {
        // Validates that entries are made
        return !TextUtils.isEmpty(date) && !TextUtils.isEmpty(weight) && TextUtils.isDigitsOnly(weight);
    }

    private void clearInputs() {
        dateInput.setText("");
        weightInput.setText("");
    }

    // Populates data records
    private void loadWeightRecords() {
        List<Map<String, String>> records = dbHelper.getAllWeightRecords();

        if (records != null && !records.isEmpty()) {
            if (recordAdapter == null) {
                recordAdapter = new RecordAdapter(records, dbHelper);
                recordRecyclerView.setLayoutManager(new LinearLayoutManager(this));
                recordRecyclerView.setAdapter(recordAdapter);
            } else {
                recordAdapter.updateData(records); // Refresh the RecyclerView table
            }
        } else {
            Toast.makeText(this, "No records found", Toast.LENGTH_SHORT).show();
        }
    }
}
