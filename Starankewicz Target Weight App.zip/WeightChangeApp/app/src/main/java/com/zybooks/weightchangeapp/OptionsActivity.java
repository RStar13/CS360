package com.zybooks.weightchangeapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

// This is currently not implemented as functionality is still to be determined.
public class OptionsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.options_menu);

        // Home button returns to dashboard
        Button homeButton = findViewById(R.id.returnHome);

        // Home Button click listener
        homeButton.setOnClickListener(v -> {
            // Navigate to the DashboardActivity
            startActivity(new Intent(this, DashboardActivity.class));
            finish();
        });
    }
}
