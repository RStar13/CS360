package com.zybooks.weightchangeapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

//Records the weight for the day
public class RecordWeightActivity extends AppCompatActivity {

    private EditText weightInput;
    private Database dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.record_weight);

        dbHelper = new Database(this);
        weightInput = findViewById(R.id.weightInput);
        Button saveWeightButton = findViewById(R.id.saveWeightButton);

        saveWeightButton.setOnClickListener(v -> saveWeight());
    }

    // Method to save weight entry to database
    private void saveWeight() {
        String weight = weightInput.getText().toString().trim();

        if (validateWeightInput(weight)) {
            String currentDate = new SimpleDateFormat("YYYY-MM-DD", Locale.getDefault()).format(new Date());

            // Calculate "Lbs until goal" using established goal weight
            String goalWeight = dbHelper.getGoalWeight();
            String lbsUntilGoal = calculateLbsUntilGoal(weight, goalWeight);

            // Save the weight record along with the "Lbs until goal" calculation
            dbHelper.addWeightRecord(currentDate, weight, lbsUntilGoal);

            Toast.makeText(this, "Weight recorded successfully", Toast.LENGTH_SHORT).show();

            // Ends activity returns to Dashboard
            finish();
        } else {
            Toast.makeText(this, "Please enter a valid weight", Toast.LENGTH_SHORT).show();
        }
    }

        //Ensures weight imput is correct
    private boolean validateWeightInput(String weight) {

        return !weight.isEmpty() && weight.matches("\\d+");
    }
        //calculates weight and handles instances if calculations are not possible due to lacking data.
    private String calculateLbsUntilGoal(String currentWeight, String goalWeight) {
        if (goalWeight != null && !goalWeight.isEmpty()) {
            try {
                int lbsUntilGoal = Integer.parseInt(currentWeight) - Integer.parseInt(goalWeight);
                return String.valueOf(lbsUntilGoal);
            } catch (NumberFormatException e) {
                return "N/A"; // Handle case where the weight cannot be parsed
            }
        } else {
            return "N/A"; // Handle case where goal weight isn't set or is invalid
        }
    }
}
