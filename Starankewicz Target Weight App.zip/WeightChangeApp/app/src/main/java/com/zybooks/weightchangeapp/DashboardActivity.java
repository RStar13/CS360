package com.zybooks.weightchangeapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

// This class is the homepage after successful login
public class DashboardActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dashboard);

        // Get the username from the login
        Intent intent = getIntent();
        String username = intent.getStringExtra("USERNAME");

        // Shows greeting for the specific username
        TextView greetingTextView = findViewById(R.id.greetingTextView);
        greetingTextView.setText("Welcome, " + username + "!");

        // Initialize buttons
        Button viewProgressButton = findViewById(R.id.navProgressButton);
        Button setTargetWeightButton = findViewById(R.id.navTargetWeightButton);
        Button optionsButton = findViewById(R.id.optionsButton);
        Button recordWeightButton = findViewById(R.id.navDailyButton);

        // OnClickListeners
        viewProgressButton.setOnClickListener(view -> {
            Intent progressIntent = new Intent(this, ProgressActivity.class);
            startActivity(progressIntent);
        });

        setTargetWeightButton.setOnClickListener(view -> {
            Intent goalIntent = new Intent(this, SetGoalActivity.class);
            startActivity(goalIntent);
        });

        optionsButton.setOnClickListener(view -> {
            Intent optionsIntent = new Intent(this, OptionsActivity.class);
            startActivity(optionsIntent);
        });

        recordWeightButton.setOnClickListener(view -> {
            Intent recordIntent = new Intent(this, RecordWeightActivity.class);
            startActivity(recordIntent);
        });
    }
}
