package com.zybooks.weightchangeapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import java.util.Map;

// This class Enables RecyclerView which reduces the amount of memory that the app needs
// to perform the table presentation in ProgressActivity
public class RecordAdapter extends RecyclerView.Adapter<RecordAdapter.RecordViewHolder> {

    private List<Map<String, String>> records;
    private Database dbHelper;

    public RecordAdapter(List<Map<String, String>> records, Database dbHelper) {
        this.records = records;
        this.dbHelper = dbHelper;
    }

    @NonNull
    @Override
    public RecordViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_record, parent, false);
        return new RecordViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecordViewHolder holder, int position) {
        Map<String, String> record = records.get(position);
        holder.dateTextView.setText(record.get("date"));
        holder.weightTextView.setText(record.get("weight"));
        holder.lbsToGoalTextView.setText(record.get("lbs_until_goal"));

        // Deletes entry by date
        holder.deleteTextView.setOnClickListener(v -> {
            dbHelper.deleteWeightRecord(record.get("date"));
            records.remove(position);
            notifyItemRemoved(position);
        });
    }

    @Override
    public int getItemCount() {
        return records.size();
    }

    public void updateData(List<Map<String, String>> newRecords) {
        this.records = newRecords;
        notifyDataSetChanged();
    }
    // Holds references for each item in the RecyclerViewer
    public static class RecordViewHolder extends RecyclerView.ViewHolder {
        TextView dateTextView, weightTextView, lbsToGoalTextView, deleteTextView;

        public RecordViewHolder(@NonNull View itemView) {
            super(itemView);
            dateTextView = itemView.findViewById(R.id.dateTextView);
            weightTextView = itemView.findViewById(R.id.weightTextView);
            lbsToGoalTextView = itemView.findViewById(R.id.lbsToGoalTextView);
            deleteTextView = itemView.findViewById(R.id.deleteTextView);
        }
    }
}
